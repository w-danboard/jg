## ES6-1
- let 和 const的应用
- 解构，剩余运算符
- set 和 map的应用
- 展开运算符
- 如何实现一个深拷贝
- defineProperty和proxy的区别和使用
- 数组的reduce方法
let num1 = 1;
let num2 = 2;
let num3 = 3;

export {
    num1,
    num2,
    num3
}
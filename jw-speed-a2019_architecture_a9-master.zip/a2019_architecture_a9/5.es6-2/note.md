1.ES6中的模块 export 和 import
2.export default 和 export的区别
3.es6中的动态导入 import()

// ----------------------------

1.es5中的类和类的继承
2.new.target
3.属性访问器
4.静态方法和静态属性
5.装饰器

// ----------------------------

1.数组reduce的用法 compose函数
2.箭头函数的使用
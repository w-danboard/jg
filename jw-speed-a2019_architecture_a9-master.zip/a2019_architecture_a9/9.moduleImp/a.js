module.exports = 'hello';

// exports = 'hello' 这个是错误用法

// es6 是合并关系 如果node中两个都写 采用的是默认导出
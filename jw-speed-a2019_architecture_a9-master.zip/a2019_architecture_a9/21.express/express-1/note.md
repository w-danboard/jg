- koa  express 中间件
- 区别koa基于promise async+await语法，express基于回调的方式 (没有基于promise)
- express 错误处理也是基于回调的
- koa-static koa-router (小)  express 自己封装一些中间件 自身就有路由系统
- express 生存时间比koa长 基于es5来写的
- ctx上下文，express只是在原生的req和res进行了扩展


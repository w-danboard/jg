- 什么是node，node能干什么?  node runtime 可以把js 运行在服务端
  js的组成部分（DOM,BOM,ECMAScript(es6模块) + libuv fs http 。。。）浏览器不能读写文件 不能控制系统文件
    node 非阻塞异步
  （单线程） java（多线程）  阻塞 非阻塞(调用方)  同步 异步 （被调用方）  
- 进程和线程的区别 node里支持子进程
- 阻塞和非阻塞 同步和异步
- node中的全局对象
- 浏览器事件环和node事件环对比